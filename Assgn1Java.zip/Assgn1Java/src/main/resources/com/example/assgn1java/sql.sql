CREATE DATABASE bird_spotting;

USE bird_spotting;

CREATE TABLE bird_sightings (
    region VARCHAR(50),
    date DATE,
    bird_count INT
);

INSERT INTO bird_sightings (region, date, bird_count) VALUES ('North Region', '2023-03-15', 10);
INSERT INTO bird_sightings (region, date, bird_count) VALUES ('South Region', '2023-03-16', 15);
INSERT INTO bird_sightings (region, date, bird_count) VALUES ('East Region', '2023-03-17', 8);
INSERT INTO bird_sightings (region, date, bird_count) VALUES ('West Region', '2023-03-18', 12);
INSERT INTO bird_sightings (region, date, bird_count) VALUES ('Central Region', '2023-03-19', 20);

show databases;
use bird_spotting;
show tables;
select * from bird_sightings;