module com.example.assgn1java {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.assgn1java to javafx.fxml;
    exports com.example.assgn1java;
}