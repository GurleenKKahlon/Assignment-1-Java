package com.example.assgn1java;

import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SwitchView extends Application {
    private BorderPane root;
    private Scene scene;

    @Override
    public void start(Stage primaryStage) {
        root = new BorderPane();
        scene = new Scene(root, 800, 600);

        Task<ObservableList<PieChart.Data>> task = new Task<>() {
            @Override
            protected ObservableList<PieChart.Data> call() throws Exception {
                // Fetch data from database
                // ...
                // Create ObservableList<PieChart.Data>
                // ...
                ObservableList<PieChart.Data> pieChartData = null;
                return pieChartData;
            }
        };

        BarGraphController barGraphController = new BarGraphController(task);
        root.setCenter(barGraphController.getPieChart());

        primaryStage.setTitle("Switch View");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Start the Task
        new Thread(task).start();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

