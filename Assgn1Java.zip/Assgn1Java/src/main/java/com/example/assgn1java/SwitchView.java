package com.example.assgn1java;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;

/**
 * Controller class for switching between views in a JavaFX application.
 */
public class SwitchView {

    @FXML
    private BorderPane root; // The root layout of the application.

    @FXML
    private Label welcomeText; // Label for displaying a welcome message.

    @FXML
    private Button barChartButton; // Button for switching to the bar chart view.

    @FXML
    private Button tableViewButton; // Button for switching to the table view.

    @FXML
    private TableView<BirdSighting> tableView; // TableView for displaying bird sightings.

    /**
     * Switches the view to the bar chart view.
     */
    @FXML
    private void switchToBarChart() {
        // Set the center of the root layout to the BarGraphController's view.
        root.setCenter(new BarGraphController().getView());
        // Disable the bar chart button to prevent multiple clicks.
        barChartButton.setDisable(true);
        // Enable the table view button.
        tableViewButton.setDisable(false);
    }

    /**
     * Switches the view to the table view.
     */
    @FXML
    private void switchToTableView() {
        // Set the center of the root layout to the table view.
        root.setCenter(tableView);
        // Enable the bar chart button.
        barChartButton.setDisable(false);
        // Disable the table view button to prevent multiple clicks.
        tableViewButton.setDisable(true);
    }
}
