package com.example.assgn1java;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Main class for the JavaFX application.
 */
public class Main extends Application {

    /**
     * The entry point for the JavaFX application.
     * @param primaryStage The primary stage of the application.
     * @throws Exception if an error occurs during application startup.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Load the FXML file for the main view.
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        // Load the root node of the scene graph from the FXML file.
        Parent root = loader.load();

        // Create a new scene with the root node and set its dimensions.
        Scene scene = new Scene(root, 800, 600);
        // Add a CSS stylesheet to the scene.
        scene.getStylesheets().add("styles.css");

        // Set the scene for the primary stage and display it.
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main method for launching the JavaFX application.
     * @param args The command-line arguments passed to the application.
     */
    public static void main(String[] args) {
        // Launch the JavaFX application.
        launch(args);
    }
}
