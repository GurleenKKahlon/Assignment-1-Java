package com.example.assgn1java;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class BarGraphController extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Connect to the database
        DatabaseConnector dbConnector = new DatabaseConnector();
        Connection conn = dbConnector.connect();

        // Retrieve data from the database
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT region, bird_count FROM bird_sightings");

        // Set up the x and y axes
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Region");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Bird Count");

        // Create the bar chart
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Bird Sightings by Region");

        // Populate the bar chart with data
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Bird Count");
        while (rs.next()) {
            series.getData().add(new XYChart.Data<>(rs.getString(1), rs.getInt(2)));
        }

        // Add the series to the bar chart
        barChart.getData().add(series);

        // Set up the scene and show the stage
        Scene scene = new Scene(barChart, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Close the database connection
        conn.close();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public Node getView() {
        Node barChart = null;
        return barChart;
    }
}