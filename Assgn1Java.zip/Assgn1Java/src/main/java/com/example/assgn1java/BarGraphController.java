package com.example.assgn1java;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class BarGraphController implements Initializable {

    @FXML
    private BarChart<String, Number> barChart;

    @FXML
    private void onToggleButtonClick() throws IOException {
        // Get the primary stage
        Stage stage = (Stage) barChart.getScene().getWindow();

        // Load the table view FXML file
        FXMLLoader loader = new FXMLLoader(getClass().getResource("table-view.fxml"));
        Parent root = loader.load();

        // Get the table view controller
        TableViewController controller = loader.getController();

        // Show the table view
        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.show();
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize the bar chart
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Region");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Bird Count");

        barChart.setTitle("Bird Sightings by Region");
        barChart.setAnimated(false); // Optional: Disable animations if desired
        barChart.getXAxis().setTickLabelRotation(90); // Rotate x-axis labels if needed

        // Fetch data from the database and populate the bar chart
        DatabaseConnector dbConnector = new DatabaseConnector();
        try (Connection conn = dbConnector.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT region, bird_count FROM bird_sightings")) {

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            while (rs.next()) {
                series.getData().add(new XYChart.Data<>(rs.getString("region"), rs.getInt("bird_count")));
            }

            barChart.getData().add(series);

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions
        }
    }

    public Node getView() {
        return barChart;
    }
}
