package com.example.assgn1java;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * A class representing a bird sighting, containing information about the region, date, and bird count.
 */
public class BirdSighting {

    private final StringProperty region; // Property representing the region of the bird sighting.
    private final StringProperty date; // Property representing the date of the bird sighting.
    private final StringProperty birdCount; // Property representing the count of birds sighted.

    /**
     * Constructs a BirdSighting object with the specified region, date, and bird count.
     * @param region The region of the bird sighting.
     * @param date The date of the bird sighting.
     * @param birdCount The count of birds sighted.
     */
    public BirdSighting(String region, String date, String birdCount) {
        // Initialize StringProperty objects with the provided values.
        this.region = new SimpleStringProperty(region);
        this.date = new SimpleStringProperty(date);
        this.birdCount = new SimpleStringProperty(birdCount);
    }

    /**
     * Gets the region of the bird sighting.
     * @return The region of the bird sighting.
     */
    public String getRegion() {
        return region.get();
    }

    /**
     * Returns the StringProperty representing the region of the bird sighting.
     * @return The StringProperty representing the region.
     */
    public StringProperty regionProperty() {
        return region;
    }

    /**
     * Sets the region of the bird sighting.
     * @param region The region to set.
     */
    public void setRegion(String region) {
        this.region.set(region);
    }

    /**
     * Gets the date of the bird sighting.
     * @return The date of the bird sighting.
     */
    public String getDate() {
        return date.get();
    }

    /**
     * Returns the StringProperty representing the date of the bird sighting.
     * @return The StringProperty representing the date.
     */
    public StringProperty dateProperty() {
        return date;
    }

    /**
     * Sets the date of the bird sighting.
     * @param date The date to set.
     */
    public void setDate(String date) {
        this.date.set(date);
    }

    /**
     * Gets the count of birds sighted.
     * @return The count of birds sighted.
     */
    public String getBirdCount() {
        return birdCount.get();
    }

    /**
     * Returns the StringProperty representing the count of birds sighted.
     * @return The StringProperty representing the bird count.
     */
    public StringProperty birdCountProperty() {
        return birdCount;
    }

    /**
     * Sets the count of birds sighted.
     * @param birdCount The count to set.
     */
    public void setBirdCount(String birdCount) {
        this.birdCount.set(birdCount);
    }
}
