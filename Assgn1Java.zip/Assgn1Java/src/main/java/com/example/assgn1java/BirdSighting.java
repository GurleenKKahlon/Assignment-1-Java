package com.example.assgn1java;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class BirdSighting {

    private final StringProperty region;
    private final StringProperty date;
    private final StringProperty birdCount;

    public BirdSighting(String region, String date, String birdCount) {
        this.region = new SimpleStringProperty(region);
        this.date = new SimpleStringProperty(date);
        this.birdCount = new SimpleStringProperty(birdCount);
    }

    public String getRegion() {
        return region.get();
    }

    public StringProperty regionProperty() {
        return region;
    }

    public void setRegion(String region) {
        this.region.set(region);
    }

    public String getDate() {
        return date.get();
    }

    public StringProperty dateProperty() {
        return date;
    }

    public void setDate(String date) {
        this.date.set(date);
    }

    public String getBirdCount() {
        return birdCount.get();
    }

    public StringProperty birdCountProperty() {
        return birdCount;
    }

    public void setBirdCount(String birdCount) {
        this.birdCount.set(birdCount);
    }
}
