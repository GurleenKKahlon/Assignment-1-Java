package com.example.assgn1java;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DatabaseConnector {
    // URL to connect to the database
    private static final String URL = "jdbc:mysql://localhost:3306/bird_spotting";
    // Username for database authentication
    private static final String USER = "root";
    // Password for database authentication
    private static final String PASS = "1234";
    // Establishes a connection to the database.
    public Connection connect() {
        try {
            // Establishes the connection using DriverManager
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            // Throws a runtime exception if connection fails
            throw new RuntimeException("Error connecting to the database", e);
        }
    }
}

