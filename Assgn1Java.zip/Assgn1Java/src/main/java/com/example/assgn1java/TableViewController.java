package com.example.assgn1java;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TableViewController {

    @FXML
    private TableView<BirdSighting> tableView;

    @FXML
    private TableColumn<BirdSighting, String> regionColumn;

    @FXML
    private TableColumn<BirdSighting, String> dateColumn;

    @FXML
    private TableColumn<BirdSighting, String> birdCountColumn;

    @FXML
    private AnchorPane rootPane;

    @FXML
    private void onToggleButtonClick() throws IOException {
        // Switch to the bar graph view
        BarGraphController barGraphController = new BarGraphController();
        rootPane.getChildren().setAll(barGraphController.getView());
    }

    @FXML
    public void initialize() {
        regionColumn.setCellValueFactory(new PropertyValueFactory<>("region"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        birdCountColumn.setCellValueFactory(new PropertyValueFactory<>("birdCount"));

        try {
            populateTableView();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    private void populateTableView() throws SQLException {
        // Connect to the database
        DatabaseConnector dbConnector = new DatabaseConnector();
        Connection conn = dbConnector.connect();

        // Retrieve data from the database
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT region, date, bird_count FROM bird_sightings");

        // Create an observable list to hold bird sightings
        ObservableList<BirdSighting> birdSightings = FXCollections.observableArrayList();

        // Populate the observable list with data from the result set
        while (rs.next()) {
            birdSightings.add(new BirdSighting(rs.getString(1), rs.getString(2), String.valueOf(rs.getInt(3))));
        }

        // Set the items of the table view
        tableView.setItems(birdSightings);

        // Close the database connection
        conn.close();
    }
}
