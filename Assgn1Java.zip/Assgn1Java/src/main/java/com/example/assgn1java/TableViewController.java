package com.example.assgn1java;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static javafx.application.Application.launch;

public class TableViewController {

    private TableView<BirdSighting> tableView;

    @FXML
    private TableColumn<BirdSighting, String> regionColumn;

    @FXML
    private TableColumn<BirdSighting, String> dateColumn;

    @FXML
    private TableColumn<BirdSighting, String> birdCountColumn;

    private ObservableList<BirdSighting> birdSightings;

    public TableViewController() {
        birdSightings = FXCollections.observableArrayList(
                new BirdSighting("Region 1", "2022-01-01", "10"),
                new BirdSighting("Region 2", "2022-01-02", "20"),
                new BirdSighting("Region 3", "2022-01-03", "30")
        );
    }

    @FXML
    public void initialize() {
        regionColumn.setCellValueFactory(new PropertyValueFactory<>("region"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        birdCountColumn.setCellValueFactory(new PropertyValueFactory<>("birdCount"));

        tableView.setItems(birdSightings);
    }

    public TableView<BirdSighting> getView() {
        return tableView;
    }

    public void start(Stage primaryStage) throws Exception {
        // Connect to the database
        DatabaseConnector dbConnector = new DatabaseConnector();
        Connection conn = dbConnector.connect();

        // Retrieve data from the database
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT region, date, bird_count FROM bird_sightings");

        // Create the table view and columns
        tableView = new TableView<>();
        TableColumn<BirdSighting, String> regionColumn = new TableColumn<>("Region");
        TableColumn<BirdSighting, String> dateColumn = new TableColumn<>("Date");
        TableColumn<BirdSighting, String> birdCountColumn = new TableColumn<>("Bird Count");

        // Set up the columns
        regionColumn.setCellValueFactory(cellData -> cellData.getValue().regionProperty());
        dateColumn.setCellValueFactory(cellData -> cellData.getValue().dateProperty());
        birdCountColumn.setCellValueFactory(cellData -> cellData.getValue().birdCountProperty());

        // Add the columns to the table view
        tableView.getColumns().addAll(regionColumn, dateColumn, birdCountColumn);

        // Populate the table view with data
        ObservableList<BirdSighting> birdSightings = FXCollections.observableArrayList();
        while (rs.next()) {
            birdSightings.add(new BirdSighting(rs.getString(1), rs.getString(2), String.valueOf(rs.getInt(3))));
        }
        tableView.setItems(birdSightings);

        // Set up the scene and show
        VBox vbox = new VBox(tableView);
        Scene scene = new Scene(vbox, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Close the database connection
        conn.close();
    }

}